# CUT-THE-FRUITS
cut,cut,cut the fruits
